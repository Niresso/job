<!DOCTYPE html >
<html >
<head>

    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>ЗАДАЧНИК</title>

    <script type="text/javascript" src="/template/bootstrap/js/bootstrap.js"></script>
    <script type="text/javascript" src="/template/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/template/bootstrap/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>

    <link href="/template/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="/template/css/main.css" rel="stylesheet" type="text/css">

    <!-- стили модального окна -->
    <link rel="stylesheet" href="/template/css/style-modal.css" rel="stylesheet">


</head>
<body>
    <div class="navbar navbar-inverse navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container">
                <ul class="nav">
                </ul>
                <ul class="nav pull-right">

                </ul>
            </div>
        </div>
    </div>

