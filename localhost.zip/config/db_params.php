<?php

// Data database

return array(
			'host' => 'localhost',
			'dbname' => 'films',
			'user' => 'root',
			'password' => '',
);