
$(document).ready(function(){
	sendAjaxForm();
	setInterval('sendAjaxForm()',1000);
});

$( document ).ready(function() {

	$("#btnn").click(
		function(){
			sendAjaxForm();
			return false;
		}
	);
});

function sendAjaxForm() {
	jQuery.ajax({
		url:     '/components/response.php',
		type:     "POST",
		dataType: "html",
		data: jQuery("#"+'ajax_form').serialize(),
		success: function(response) {

			result = jQuery.parseJSON(response);

			$("div#result_form").empty();
			var aa = document.getElementById('result_form').innerHTML;
			for (var n=0; n<result.length;n++){
				aa +=  "<tr><td>"
					+ result[n].id + " </td><td> "
					+ result[n].name + "</td><td>"
					+ result[n].actors + "</td><td>"
					+ result[n].year + "</td><td><a href='films/delete/" +
					+ result[n].id + "' class='btn'>Delete</a>"
				;
				document.getElementById('result_form').innerHTML =
					"<table class='table table-striped'><tr><td>ID:</td><td>Название:</td><td>Актери:</td><td>Год выпуска:</td><td>Удалить:</td></tr>"
					+aa + "</tr></table>";
			}

		}
	});
}
